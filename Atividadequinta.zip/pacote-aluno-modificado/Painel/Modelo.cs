using Microsoft.EntityFrameworkCore;
namespace Painel;
public sealed class Pedido
{
    public int Id { get; set; }
    public string Status { get; set; } = "Pendente";
}
public sealed record AlterarStatus(string Status);
public sealed class LojaDb(DbContextOptions<LojaDb> options) : DbContext(options)
{
    public DbSet<Pedido> Pedidos => Set<Pedido>();
}
public static class Regras
{
    // ATIVIDADE A: Cancelado acrescentado.
    public static readonly string[] StatusPermitidos = ["Pendente", "Em preparo", "Concluido", "Cancelado"];
}
