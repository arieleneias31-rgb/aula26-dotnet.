using System.Net;
using System.Net.Http.Json;
using Xunit;
namespace Painel.Tests;
public sealed class ApiTests
{
    [Fact]
    public async Task ConsultaRetornaPedidoETag()
    {
        using var fabrica = new Fabrica(); using var cliente = fabrica.CreateClient();
        var resposta = await cliente.GetAsync("/api/pedidos/1");
        Assert.Equal(HttpStatusCode.OK, resposta.StatusCode);
        Assert.NotNull(resposta.Headers.ETag);
        var pedido = await resposta.Content.ReadFromJsonAsync<PedidoDto>();
        Assert.Equal("Pendente", pedido!.Status);
    }
    [Fact]
    public async Task TagIgualRetorna304SemCorpo()
    {
        using var fabrica = new Fabrica(); using var cliente = fabrica.CreateClient();
        var primeira = await cliente.GetAsync("/api/pedidos/1");
        using var pedido = new HttpRequestMessage(HttpMethod.Get, "/api/pedidos/1");
        pedido.Headers.IfNoneMatch.Add(primeira.Headers.ETag!);
        var segunda = await cliente.SendAsync(pedido);
        Assert.Equal(HttpStatusCode.NotModified, segunda.StatusCode);
        Assert.Empty(await segunda.Content.ReadAsByteArrayAsync());
    }
    [Fact]
    public async Task AlteracaoInvalidaTagAntiga()
    {
        using var fabrica = new Fabrica(); using var cliente = fabrica.CreateClient();
        var primeira = await cliente.GetAsync("/api/pedidos/1");
        var alteracao = await cliente.PutAsJsonAsync("/api/pedidos/1/status", new { status = "Concluido" });
        Assert.Equal(HttpStatusCode.NoContent, alteracao.StatusCode);
        using var pedido = new HttpRequestMessage(HttpMethod.Get, "/api/pedidos/1");
        pedido.Headers.IfNoneMatch.Add(primeira.Headers.ETag!);
        var segunda = await cliente.SendAsync(pedido);
        Assert.Equal(HttpStatusCode.OK, segunda.StatusCode);
        Assert.NotEqual(primeira.Headers.ETag, segunda.Headers.ETag);
        Assert.Equal("Concluido", (await segunda.Content.ReadFromJsonAsync<PedidoDto>())!.Status);
    }
    [Fact]
    public async Task StatusInvalidoRetorna400SemAlterarPedido()
    {
        using var fabrica = new Fabrica(); using var cliente = fabrica.CreateClient();
        var resposta = await cliente.PutAsJsonAsync("/api/pedidos/1/status", new { status = "Desconhecido" });
        Assert.Equal(HttpStatusCode.BadRequest, resposta.StatusCode);
        Assert.Equal("Pendente", (await cliente.GetFromJsonAsync<PedidoDto>("/api/pedidos/1"))!.Status);
    }
    [Fact]
    public async Task FabricaNovaNaoHerdouAlteracao()
    {
        using var a = new Fabrica(); using var ca = a.CreateClient();
        await ca.PutAsJsonAsync("/api/pedidos/1/status", new { status = "Concluido" });
        using var b = new Fabrica(); using var cb = b.CreateClient();
        Assert.Equal("Pendente", (await cb.GetFromJsonAsync<PedidoDto>("/api/pedidos/1"))!.Status);
    }
    [Fact]
    public async Task CancelarRetorna204EConfirmaStatusPorGet()
    {
        using var fabrica = new Fabrica(); using var cliente = fabrica.CreateClient();
        var resposta = await cliente.PutAsJsonAsync("/api/pedidos/1/status", new { status = "Cancelado" });
        Assert.Equal(HttpStatusCode.NoContent, resposta.StatusCode);
        var pedido = await cliente.GetFromJsonAsync<PedidoDto>("/api/pedidos/1");
        Assert.Equal("Cancelado", pedido!.Status);
    }
    public sealed record PedidoDto(int Id, string Status);
}
