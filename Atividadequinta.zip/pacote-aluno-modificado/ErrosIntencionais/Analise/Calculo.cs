namespace Analise;
// ERRO INTENCIONAL DE QUALIDADE: método não usa estado da instância (CA1822).
// Separado da solução principal; execute a compilação indicada no roteiro.
public class Calculo
{
    public static int Dobro(int numero) => numero * 2;
}
