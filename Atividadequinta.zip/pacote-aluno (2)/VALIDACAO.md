VALIDAÇÃO — AULA GUIADA .NET — 26/10/2026
Preparada em 25/10/2026 para revisão do Prof. Carlos Allexandre.

ENTREGA
HTML autônomo com roteiro de 160 min, temas claro/escuro, impressão, copiar comandos e checklist local; projeto inicial; resolução separada; cinco testes iniciais e um adicional na resolução; demonstração de analisador; rubrica proposta e evidências em branco. Não publicado no portal. Não há cobrança nem envio de dados pelo HTML.
A referência recebida da aula anterior foi uma transcrição textual. Foram mantidos a sequência autoinstrucional e os elementos conhecidos de identidade (verde/creme, nome e temas). Não foi possível comparar visualmente com o HTML original da aula anterior.

AMBIENTE
Ubuntu 24.04 x64; SDK .NET 8.0.415; Microsoft.NETCore.App e Microsoft.AspNetCore.App 8.0.21; MSBuild 17.11.48; Node.js 24.22.1.
Pacotes fixados: EF Core SQLite e Mvc.Testing 8.0.21, SignalR JavaScript 8.0.7, Microsoft.NET.Test.Sdk 17.11.1, xUnit 2.9.2, runner Visual Studio 2.8.2. Analisadores Roslyn e dotnet format: fornecidos pelo SDK.
O cliente SignalR e sua licença MIT acompanham o pacote, sem dependência de CDN em aula. Primeiro restore ainda requer NuGet.
Versões didáticas fixadas para continuidade com .NET 8; não são as mais recentes. .NET 8 encerra suporte em 10/11/2026. xUnit 2 é legado. Planejar migração e revalidação antes de reutilizar como base de produção.

EXECUÇÕES REALIZADAS
1. Instalação do SDK: primeira extração teve erro de proprietário no ambiente; nova execução com tar --no-same-owner reconheceu a instalação. dotnet --info confirmou SDK/runtime.
2. A CLI dotnet apresentou falha de informações de processo neste ambiente. A solução foi compilada pelo mesmo MSBuild do SDK, invocado diretamente:
   dotnet /tmp/aula-dotnet/sdk/8.0.415/MSBuild.dll Aula26.sln /restore /t:Build /m:1 /nodeReuse:false
   Aluno: saída 0, zero avisos e zero erros.
   Professor/Resolucao: saída 0, zero avisos e zero erros.
3. VSTest padrão falhou internamente antes de executar as asserções. NÃO houve dotnet test padrão aprovado nem relatório TRX válido nesta validação.
4. Um executor temporário chamou sequencialmente os métodos [Fact] compilados, mantendo WebApplicationFactory, SQLite e asserções xUnit reais. Resultado: 5/5 métodos do aluno e 6/6 da resolução aprovados, ambos com saída 0. Não é execução pelo runner padrão nem verifica paralelismo do runner. O executor fica apenas nos registros do professor.
   Verificações: GET com tag; 304 sem corpo; alteração invalida tag; 400 sem alterar banco; isolamento entre fábricas; Cancelado persistido (resolução).
5. Aplicação real em Kestrel local: executada a DLL compilada, em porta 5080 com arquivo SQLite exclusivo de validação. Script Node.js http-signalr.mjs, saída 0:
   - HTTP 200 e ETag; 304 sem corpo; tag fraca no GET aceita.
   - Negociação SignalR e WebSocket com handshake reais.
   - Streaming entregou 0,20,40,60,80,100 e conclusão.
   - Cancelamento de um segundo streaming interrompeu a sequência.
   - PUT válido emitiu PedidoAtualizado; GET com tag antiga retornou 200 e nova tag.
   - Duas consultas seguidas em cada endpoint de cache retornaram a mesma representação.
   Não foram cronometradas expiração de 15 s nem todas as políticas de cache.
6. Exemplo intencional: MSBuild com /p:WarningsAsErrors=CA1822 retornou 1 e o diagnóstico CA1822. Versão corrigida static retornou 0, sem avisos/erros.
7. node --check nos scripts próprios de aluno/professor e no script inline do roteiro: aprovado. Parser HTML não encontrou IDs duplicados. Integridade dos ZIPs conferida e fontes separadas das resoluções.

PENDÊNCIAS
- Executar dotnet restore/build/test/format pelos comandos normais no computador do laboratório. O format não concluiu neste ambiente; não há afirmação de conformidade integral à formatação.
- Conferir a UI no navegador: duas abas, falha inicial, queda/reconexão, recuperação pelo GET, temas, teclado, tamanho móvel, copiar e impressão. As verificações SignalR acima usaram cliente de protocolo em Node, não o JavaScript da interface em um navegador.
- Revisão pedagógica final, rubrica e prazo propostos pelo professor.
- A integração contínua do GitHub é exemplo opcional; não foi executada em serviço remoto.

LIMITES DIDÁTICOS
Dados fictícios e uso local. Não inclui autenticação, autorização, escrita concorrente otimista, fila durável ou outbox. Gravação e notificação não são transação única. Reconexão não recupera automaticamente histórico de eventos ou stream. SQLite não comprova compatibilidade com outros bancos. Não é um sistema pronto para produção.

FONTES
Links oficiais estão na seção Ajuda e fontes do HTML; documentação e páginas NuGet consultadas em 25/10/2026. A fonte textual de continuidade é a aula enviada pelo professor, de 19/10/2026.

STATUS
Pronto para revisão do professor. Compilação e verificações funcionais descritas acima realizadas; publicação para os alunos depende da conferência final de ambiente e navegador. Nenhuma publicação realizada nesta tarefa.
