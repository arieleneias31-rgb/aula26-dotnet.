# Aula 26/10/2026 — início rápido
Prof. Carlos Allexandre · Programação Aplicada em .NET · UNIP ADS

1. Extraia o ZIP. No VS Code: Arquivo → Abrir Pasta → pasta com Aula26.sln.
2. Abra Aula_Guiada.html no navegador para ler as instruções.
3. No VS Code: Terminal → Novo Terminal. Execute:

```sh
dotnet --list-sdks
dotnet restore Aula26.sln
dotnet build Aula26.sln --no-restore
dotnet run --project Painel --no-build --urls http://localhost:5080
```

4. Abra http://localhost:5080 em duas abas. A página da aula é diferente da aplicação local.
5. Em outro terminal, na mesma pasta: `dotnet test Aula26.sln`.
6. Siga a atividade individual do roteiro e preencha ENTREGA.md e evidencias.md.

SDK de referência: 8.0.415 (global.json aceita patches posteriores na mesma faixa). Runtime ASP.NET Core 8.0.21. EF Core SQLite e Mvc.Testing 8.0.21; SignalR JS 8.0.7 incluído localmente com licença; Test SDK 17.11.1; xUnit 2.9.2; runner 2.8.2. Roslyn/analisadores e dotnet format são os fornecidos pelo SDK. Sem Docker ou banco externo.

Esta é uma base didática fixada para continuidade com a aula anterior, não uma seleção das últimas versões. .NET 8 encerra suporte em 10/11/2026. xUnit 2 é legado. Planejar atualização conjunta e revalidação para próximas edições e produção.

O banco aula26.db é criado automaticamente. Os testes usam bancos nomeados em memória, um por fábrica. Não use dados reais. O servidor deve ficar em localhost. Após alterações no C#, pare e execute novamente sem --no-build para recompilar. HTML/JS: recarregue a página.

Sem NuGet, use máquina previamente preparada ou registre não executado e combine validação posterior. Não desative proteção de rede.

ErrosIntencionais não participa da solução: contém diagnóstico CA1822 deliberado. `.github/workflows/qualidade.yml` é apenas exemplo opcional; GitHub não é necessário.

Consulte VALIDACAO.md para o que foi efetivamente verificado antes da entrega.
