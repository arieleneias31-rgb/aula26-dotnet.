# Evidências reais
Não copie saídas esperadas como se fossem executadas. Oculte dados sensíveis.

| Cenário | Procedimento/entrada | Resultado esperado | Resultado observado | Evidência | Status |
|---|---|---|---|---|---|
| Notificação | Salvar Cancelado na aba A | Atualização na B | | | |
| Stream | Iniciar/cancelar | Interromper sequência | | | |
| Reconexão | Parar/reiniciar servidor | GET sincroniza estado | | | |
| ETag | GET/repetir/alterar | 200/304/200 | | | |
| Testes | dotnet test | Aprovação | | | |
| Analisador | Build antes/depois | CA1822/correção | | | |

Para cada captura/log: legenda, comando executado, trecho observado e interpretação. Registre "não executado" quando aplicável.
