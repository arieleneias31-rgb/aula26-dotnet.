# Minha entrega
Nome: [PREENCHA] · RA: [PREENCHA] · Turma: [PREENCHA]
SDK e sistema: [PREENCHA]
Comandos usados: [PREENCHA]

## Alterações e previsão
Mensagem autoral: [PREENCHA]
Previsão antes de executar a validação condicional: [PREENCHA]
Resultado observado e comparação: [PREENCHA]

## Explique em 2–4 linhas cada
1. Notificação versus consulta: [PREENCHA]
2. no-cache versus no-store: [PREENCHA]
3. Por que o banco de teste é efêmero e isolado? [PREENCHA]
4. Por que testes HTTP não comprovam reconexão do cliente? [PREENCHA]

## Investigação
Dificuldade, hipótese, procedimento e correção: [PREENCHA]
Limitações e itens não executados: [PREENCHA]
Referências que realmente consultei: [PREENCHA]
