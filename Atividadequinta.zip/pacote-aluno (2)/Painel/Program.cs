using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Net.Http.Headers;
using Painel;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSignalR();
// A configuração é substituída pela fábrica de testes. Cada contexto abre sua conexão.
builder.Services.AddDbContext<LojaDb>((sp, options) => options.UseSqlite(
    sp.GetRequiredService<IConfiguration>().GetConnectionString("Loja") ?? "Data Source=aula26.db"));
builder.Services.AddResponseCaching();
builder.Services.AddOutputCache();
var app = builder.Build();
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<LojaDb>();
    db.Database.EnsureCreated();
    if (!db.Pedidos.Any())
    {
        db.Pedidos.AddRange(new Pedido { Id = 1, Status = "Pendente" }, new Pedido { Id = 2, Status = "Pendente" });
        db.SaveChanges();
    }
}
app.UseDefaultFiles();
app.UseStaticFiles();
app.UseResponseCaching();
app.UseOutputCache();
app.MapHub<PedidosHub>("/hubs/pedidos");

app.MapGet("/api/pedidos/{id:int}", async (int id, LojaDb db, HttpContext ctx) =>
{
    var pedido = await db.Pedidos.AsNoTracking().SingleOrDefaultAsync(p => p.Id == id);
    if (pedido is null) { return Results.NotFound(); }
    // A tag deriva dos mesmos bytes devolvidos, não de um relógio ou contador independente.
    byte[] bytes = JsonSerializer.SerializeToUtf8Bytes(new { pedido.Id, pedido.Status }, new JsonSerializerOptions(JsonSerializerDefaults.Web));
    string tag = "\"" + Convert.ToHexString(SHA256.HashData(bytes)) + "\"";
    ctx.Response.Headers.ETag = tag;
    ctx.Response.Headers.CacheControl = "private, no-cache";
    var recebidas = ctx.Request.GetTypedHeaders().IfNoneMatch;
    if (recebidas is not null && recebidas.Any(t => t.Tag.Value == "*" || t.Compare(new EntityTagHeaderValue(tag), useStrongComparison: false)))
    {
        return Results.StatusCode(StatusCodes.Status304NotModified);
    }
    return Results.Bytes(bytes, "application/json; charset=utf-8");
});
app.MapPut("/api/pedidos/{id:int}/status", async (int id, AlterarStatus entrada, LojaDb db, IHubContext<PedidosHub> hub) =>
{
    if (!Regras.StatusPermitidos.Contains(entrada.Status)) { return Results.BadRequest(new { erro = "Status inválido" }); }
    var pedido = await db.Pedidos.FindAsync(id);
    if (pedido is null) { return Results.NotFound(); }
    pedido.Status = entrada.Status;
    await db.SaveChangesAsync();
    // Demonstração em uma instância: persistir e notificar não é uma transação atômica.
    await hub.Clients.All.SendAsync("PedidoAtualizado", new { pedido.Id, pedido.Status });
    return Results.NoContent();
});
// Endpoints distintos para comparar os dois middlewares, usando somente dados fictícios.
app.MapGet("/api/cache-resposta", (HttpContext ctx) =>
{
    ctx.Response.Headers.CacheControl = "public, max-age=15";
    return Results.Ok(new { geradoEm = DateTimeOffset.UtcNow });
});
app.MapGet("/api/cache-saida", () => Results.Ok(new { geradoEm = DateTimeOffset.UtcNow }))
    .CacheOutput(policy => policy.Expire(TimeSpan.FromSeconds(15)));
app.Run();
public partial class Program { }
