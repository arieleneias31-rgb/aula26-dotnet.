using System.Runtime.CompilerServices;
using Microsoft.AspNetCore.SignalR;
namespace Painel;
public sealed class PedidosHub : Hub
{
    public async IAsyncEnumerable<int> Progresso([EnumeratorCancellation] CancellationToken cancelamento)
    {
        // Demonstração de streaming: não representa o andamento real de um pedido.
        for (int valor = 0; valor <= 100; valor += 20)
        {
            cancelamento.ThrowIfCancellationRequested();
            yield return valor;
            await Task.Delay(500, cancelamento);
        }
    }
}
