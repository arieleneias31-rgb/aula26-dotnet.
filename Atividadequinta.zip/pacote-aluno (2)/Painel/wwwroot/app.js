"use strict";
const el = id => document.getElementById(id);
const registrar = texto => { el("log").textContent = `${new Date().toLocaleTimeString()} ${texto}
` + el("log").textContent; };
let tag = null, copia = null, assinatura = null, conectando = false;
// Serializa leituras para evitar que uma resposta antiga sobrescreva outra mais recente.
let leituras = Promise.resolve();
function consultar() {
    leituras = leituras.catch(() => {}).then(async () => {
        const headers = tag && copia ? { "If-None-Match": tag } : {};
        const r = await fetch("/api/pedidos/1", { headers, cache: "no-store" });
        registrar(`GET: ${r.status}; ETag: ${r.headers.get("ETag")}`);
        if (r.status === 304) {
            if (!copia) throw new Error("304 sem cópia local");
        } else {
            if (!r.ok) throw new Error(`HTTP ${r.status}`);
            copia = await r.json(); tag = r.headers.get("ETag");
        }
        el("pedido").textContent = `Pedido ${copia.id}: ${copia.status}`;
    });
    return leituras;
}
const conexao = new signalR.HubConnectionBuilder().withUrl("/hubs/pedidos")
    .withAutomaticReconnect([0, 2000, 5000, 10000]).build();
function estado(texto) { el("conexao").textContent = texto; registrar(texto); }
conexao.on("PedidoAtualizado", aviso => {
    // A: modifique a mensagem para incluir o status, preservando textContent.
    registrar(`Notificação do pedido ${aviso.id}`);
    consultar().catch(erro);
});
conexao.onreconnecting(() => { estado("Reconectando…"); assinatura = null; el("progresso").textContent = "Stream interrompido; reinicie após reconectar."; });
conexao.onreconnected(() => { estado("Conectado novamente"); consultar().catch(erro); });
conexao.onclose(() => { estado("Desconectado — clique em conectar"); assinatura = null; });
function erro(e) { registrar(`Erro: ${e.message || e}`); }
async function conectar() {
    if (conectando || conexao.state !== signalR.HubConnectionState.Disconnected) return;
    conectando = true;
    try { await conexao.start(); estado("Conectado"); await consultar(); }
    catch (e) { estado("Falha inicial — confira o servidor e clique em conectar"); erro(e); }
    finally { conectando = false; }
}
el("conectar").onclick = conectar;
el("consultar").onclick = () => consultar().catch(erro);
el("reiniciar").onclick = () => { leituras = leituras.catch(() => {}).then(() => { tag = null; copia = null; }); consultar().catch(erro); };
el("alterar").onclick = async () => {
    try {
        const r = await fetch("/api/pedidos/1/status", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: el("status").value }) });
        registrar(`PUT: ${r.status}`); if (!r.ok) throw new Error(await r.text());
        // O GET seguinte pode vir também da notificação: são caminhos diferentes.
        await consultar();
    } catch (e) { erro(e); }
};
el("stream").onclick = () => {
    if (conexao.state !== signalR.HubConnectionState.Connected || assinatura) return;
    assinatura = conexao.stream("Progresso").subscribe({
        next: valor => { el("progresso").textContent = `${valor}%`; registrar(`Stream: ${valor}`); },
        complete: () => { assinatura = null; registrar("Stream concluído"); },
        error: e => { assinatura = null; erro(e); }
    });
};
el("cancelar").onclick = () => { assinatura?.dispose(); assinatura = null; el("progresso").textContent = "Cancelado pelo cliente"; registrar("Cancelamento enviado"); };
el("tema").onclick = () => document.documentElement.classList.toggle("escuro");
conectar();
