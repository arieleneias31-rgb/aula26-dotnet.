using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Data.Sqlite;
namespace Painel.Tests;
public sealed class Fabrica : WebApplicationFactory<Program>
{
    private readonly string _conexao = $"Data Source=teste-{Guid.NewGuid():N};Mode=Memory;Cache=Shared";
    private readonly SqliteConnection _ancora;
    public Fabrica()
    {
        // Mantém o banco vivo; os DbContexts abrem conexões próprias para esse nome único.
        _ancora = new SqliteConnection(_conexao);
        _ancora.Open();
    }
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        builder.UseSetting("ConnectionStrings:Loja", _conexao);
    }
    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
        if (disposing) { _ancora.Dispose(); }
    }
}
